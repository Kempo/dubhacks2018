import './polyfills';
import 'watson-react-components/dist/css/watson-react-components.css';
import React from 'react';
import ReactDOM from 'react-dom';
import Index from './index.jsx';
import './style.css';

ReactDOM.render(<Index/>, document.getElementById('root'));
